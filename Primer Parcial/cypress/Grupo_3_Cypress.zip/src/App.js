import React from 'react';
import RootNavigation from './navigation/RootNavigation';

export default function App() {
  return <RootNavigation />;
}
