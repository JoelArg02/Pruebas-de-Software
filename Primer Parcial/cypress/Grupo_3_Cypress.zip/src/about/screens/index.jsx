import React from 'react'
import { Container } from 'react-bootstrap'

export default function About() {
  return (
    <Container className="mt-4">
      <h1>Acerca de Nosotros</h1>
      <p>Esta es una web de prueba para aprender React y pruebas de software.</p>
    </Container>
  )
}
